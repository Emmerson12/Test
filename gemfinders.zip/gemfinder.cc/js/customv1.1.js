/* Theme Name: Home services *
 * Developed By: Pratiksha Sharma*
 * Version: 1.1, 2021*
 */
$('.singlecoinlink').click(function() {
    var a = $(this);
    openlink(a);
});

function openlink(key) {
    var loc = $(key).attr('data-href');
    window.location = loc;
}
/*  Captcha code start */
var key;
var count = 0;
var value = 0;
var status = 0;
var text = 0;
var $this
$('.singlecoinlink .badge').click(function(e) {
    key = $(this);
    value = $(key).attr('data-value');
    status = $(key).attr('data-status');
    upvote(key);
});


function upvote(key) {
    //console.log(key)
    if (!e) var e = window.event;
    e.cancelBubble = true;
    if (e.stopPropagation) e.stopPropagation();
    $this = $(key);
    key = key;
    text = parseInt($(key).children('span').text());
    value = parseInt($(key).data("value"));
    status = parseInt($(key).data("status"));

    $('#captchaModal').modal('show');
    /* count = count + 1;
     if (count > 4 ) {
         $('#captchaModal').modal('show');
     } else {
         $.ajax({
             url: 'vote',
             type: 'POST',
             data: { coin_id: value, status: status },
             headers: {
                 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
             },
             success: function(response) { 
                 text = response.count;
                 status = response.status;
                 $(".btn_" + value).attr('data-status', response.status);
                 $(".btn_" + value).data('status', response.status);
                 if($("#btnp_" + value)){
                     $("#btnp_" + value).data('status', response.status);
                 }
                 changebadge(text, $this, value, status);
             }
         });
     }*/

}


function upvotenew() {
    //var $this = $(key);  
    var recaptch = $("#g-recaptcha-response").val();
    $.ajax({
        url: 'vote',
        type: 'POST',
        data: {
            coin_id: value,
            status: status,
            recaptch: recaptch
        },
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        success: function(response) {
            text = response.count;
            status = response.status;
            if (status == 0) {
                alert("invalid Catcha")
                return false;
            }


            $(".btn_" + value).attr('data-status', response.status);
            $(".btn_" + value).data('status', response.status);
            if ($("#btnp_" + value)) {
                $("#btnp_" + value).data('status', response.status);
            }
            changebadge(text, $this, value, status);
        }
    });
}


function captchaHide(token) {
    count = 0;
    $('#captchaModal').modal('hide');
    upvotenew();
    grecaptcha.reset();
    //changebadge(text, $this, value, status);
}

function changebadge(text, $this, value, status) {
    //console.log("$this")
    //console.log($this)
    if (status == 1) {

        // 		text = text +1;
        $this.removeClass('badge-danger').addClass('badge-success').html('<i class="fas fa-arrow-up mr-2"></i><span>' + text + '</span>');
    } else {
        // 		text = text -1;
        $this.removeClass('badge-success').addClass('badge-danger').html('<i class="fas fa-arrow-up mr-2"></i><span>' + text + '</span>');
    }

}
/* Captcha code end*/


$('.copy-chain-btn').click(function() {
    var binance = $('#binance_address').text();
    var binance = $.trim(binance);
    var $temp = $("<input>");
    $("body").append($temp);
    $temp.val(binance).select();
    document.execCommand("copy");
    $temp.remove();
    $(".copy-chain-btn").text("copied");
});
$('.copy-chain-btn2').click(function() {
    var etherum = $('#etherum_address').text();
    var etherum = $.trim(etherum);
    var $temp = $("<input>");
    $("body").append($temp);
    $temp.val(etherum).select();
    document.execCommand("copy");
    $temp.remove();
    $(".copy-chain-btn2").text("copied");
});

$('.copy-chain-btn3').click(function() {
    var etherum = $('#polygon_address').text();
    var etherum = $.trim(etherum);
    var $temp = $("<input>");
    $("body").append($temp);
    $temp.val(etherum).select();
    document.execCommand("copy");
    $temp.remove();
    $(".copy-chain-btn3").text("copied");
});


$(document).on("click", "#banner_click", function(e) {
    var id = $(this).attr('data-id');
    var url = $(this).attr('data-url');


    $.ajax({
        url: url,
        type: 'POST',
        data: {
            banner_id: id
        },
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        success: function(response) {
            text = response.count;
            status = response.status;
            if (status == 0) {
                alert("invalid Catcha")
                return false;
            }


            $(".btn_" + value).attr('data-status', response.status);
            $(".btn_" + value).data('status', response.status);
            if ($("#btnp_" + value)) {
                $("#btnp_" + value).data('status', response.status);
            }
            changebadge(text, $this, value, status);
        }
    });

});

$(document).on("click", ".floating_close", function(e) {
    var url = $(this).attr('data-url');

    $.ajax({
        url: url,
        type: 'GET',

        success: function(response) {

            $(".floatingBanner").remove();
        }
    });

});

$(document).on("click", ".fbanner_click", function(e) {
    var id = $(this).attr('data-id');
    var url = $(this).attr('data-url');
    $.ajax({
        url: url,
        type: 'POST',
        data: {
            id: id
        },
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        success: function(response) {

        }
    });
});

$(document).on("click", ".popup_close", function(e) {
    var url = $(this).attr('data-url');

    $.ajax({
        url: url,
        type: 'GET',

        success: function(response) {
            // jQuery("#popupmodal").modal('hide');
            jQuery(".popubanner").remove();

        }
    });

});


$(document).on("click", ".popup_click", function(e) {
    var id = $(this).attr('data-id');
    var url = $(this).attr('data-url');
    $.ajax({
        url: url,
        type: 'POST',
        data: {
            id: id
        },
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        success: function(response) {

        }
    });
});